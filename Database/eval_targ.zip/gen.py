"""
Chess Position Generator and Evaluator
Generates chess positions along Stockfish's best move path and evaluates all legal moves
"""

import chess
import chess.engine
import csv
import os
import time
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Tuple, Dict, Optional
import re
import multiprocessing
from multiprocessing import Process, Queue, Lock
import psutil

class ChessPositionGenerator:
    def __init__(self, stockfish_path: str = "stockfish", movetime_ms: int = 100, chunk_id: int = 0):
        """
        Initialize the chess position generator
        
        Args:
            stockfish_path: Path to stockfish executable
            movetime_ms: Time in milliseconds for stockfish to think per move
            chunk_id: The specific chunk ID this generator will work on
        """
        self.stockfish_path = stockfish_path
        self.movetime_ms = movetime_ms
        self.engine = None
        self.data_dir = Path("data")
        self.positions_generated = 0
        self.chunk_data = []
        self.current_chunk = chunk_id
        self.rows_per_chunk = 100000  # Fixed at 100k
        
        # Create directories if they don't exist
        self.data_dir.mkdir(exist_ok=True)
    
    def clear_console(self):
        """Clear console screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def evaluate_position(self, fen: str) -> Optional[int]:
        """Evaluate a position using Stockfish, returns centipawns"""
        try:
            board = chess.Board(fen)
            info = self.engine.analyse(board, chess.engine.Limit(time=self.movetime_ms/1000))
            
            if "score" in info:
                score = info["score"]
                # Get score from white's perspective
                pov_score = score.white()
                
                if pov_score.is_mate():
                    # Return large value for mate
                    mate_in = pov_score.mate()
                    if mate_in is not None:
                        return 30000 if mate_in > 0 else -30000
                else:
                    # Return centipawn value
                    cp = pov_score.score()
                    return cp if cp is not None else 0
            return 0
        except Exception as e:
            print(f"Error evaluating position: {e}")
            return None
    
    def write_chunk(self):
        """Write chunk data to CSV file"""
        if not self.chunk_data:
            return
        
        filename = self.data_dir / f"chunk_{self.current_chunk}_{self.rows_per_chunk}.csv"
        
        with open(filename, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['cp', 'fen'])  # Header
            writer.writerows(self.chunk_data)
        
        print(f"\nChunk {self.current_chunk} saved: {filename}")
        self.chunk_data = []
    
    def generate_chunk(self, progress_queue: Optional[Queue] = None) -> int:
        """
        Generate a single chunk of chess positions
        
        Returns:
            Number of positions generated
        """
        chunk_start_time = time.time()
        last_progress_percent = -1
        
        try:
            self.engine = chess.engine.SimpleEngine.popen_uci(self.stockfish_path)
            
            while len(self.chunk_data) < self.rows_per_chunk:
                # Start a new game
                board = chess.Board()
                
                # Play a game following best moves
                while not board.is_game_over() and len(self.chunk_data) < self.rows_per_chunk:
                    # Get best move from current position
                    result = self.engine.play(board, chess.engine.Limit(time=self.movetime_ms/1000))
                    best_move = result.move
                    
                    if best_move is None:
                        break
                    
                    # Evaluate current position (before move)
                    current_eval = self.evaluate_position(board.fen())
                    if current_eval is not None:
                        self.chunk_data.append([current_eval, board.fen()])
                        self.positions_generated += 1
                    
                    # Generate and evaluate all legal moves from current position
                    for move in board.legal_moves:
                        if len(self.chunk_data) >= self.rows_per_chunk:
                            break
                            
                        # Make move temporarily
                        board.push(move)
                        
                        # Evaluate position after move
                        eval_score = self.evaluate_position(board.fen())
                        if eval_score is not None:
                            self.chunk_data.append([eval_score, board.fen()])
                            self.positions_generated += 1
                        
                        # Undo move
                        board.pop()
                    
                    # Make the best move
                    board.push(best_move)
                    
                    # Update progress
                    current_progress = int((len(self.chunk_data) / self.rows_per_chunk) * 100)
                    if current_progress != last_progress_percent:
                        last_progress_percent = current_progress
                        if progress_queue:
                            progress_queue.put({
                                'chunk_id': self.current_chunk,
                                'progress': current_progress,
                                'positions': len(self.chunk_data),
                                'elapsed': time.time() - chunk_start_time
                            })
            
            # Write chunk
            self.write_chunk()
            
            # Send completion message
            if progress_queue:
                progress_queue.put({
                    'chunk_id': self.current_chunk,
                    'progress': 100,
                    'positions': self.positions_generated,
                    'elapsed': time.time() - chunk_start_time,
                    'completed': True
                })
            
            return self.positions_generated
            
        finally:
            if self.engine:
                self.engine.quit()


def worker_process(stockfish_path: str, movetime_ms: int, chunk_id: int, progress_queue: Queue):
    """Worker process to generate a single chunk"""
    generator = ChessPositionGenerator(stockfish_path, movetime_ms, chunk_id)
    generator.generate_chunk(progress_queue)


class ParallelChessGenerator:
    def __init__(self, stockfish_path: str = "stockfish"):
        """Initialize the parallel chess generator"""
        self.stockfish_path = stockfish_path
        self.data_dir = Path("data")
        self.data_dir.mkdir(exist_ok=True)
        
    def find_next_chunk_id(self) -> int:
        """Find the next available chunk ID by checking existing files"""
        if not self.data_dir.exists():
            return 0
        
        # Pattern to match chunk files: chunk_<id>_<rows>.csv
        pattern = re.compile(r'chunk_(\d+)_\d+\.csv')
        max_id = -1
        
        for file in self.data_dir.glob('chunk_*.csv'):
            match = pattern.match(file.name)
            if match:
                chunk_id = int(match.group(1))
                max_id = max(max_id, chunk_id)
        
        # Return the next available ID
        return max_id + 1
    
    def clear_console(self):
        """Clear console screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def print_progress(self, progress_data: Dict[int, Dict], num_chunks: int, 
                      start_time: float, movetime_ms: int, parallel_workers: int):
        """Print progress information for all chunks"""
        self.clear_console()
        elapsed = time.time() - start_time
        
        print("=" * 80)
        print(f"Chess Position Generator - Parallel Execution ({parallel_workers} workers)")
        print("=" * 80)
        
        # Calculate overall progress
        total_positions = sum(p.get('positions', 0) for p in progress_data.values())
        total_progress = sum(p.get('progress', 0) for p in progress_data.values()) / num_chunks
        completed_chunks = sum(1 for p in progress_data.values() if p.get('completed', False))
        
        print(f"Overall Progress: {total_progress:.1f}% | Chunks: {completed_chunks}/{num_chunks}")
        print(f"Total Positions Generated: {total_positions:,}")
        print(f"Move Time: {movetime_ms}ms | Elapsed: {timedelta(seconds=int(elapsed))}")
        
        # Estimate remaining time
        if total_progress > 0:
            estimated_total_time = elapsed / (total_progress / 100)
            remaining_time = estimated_total_time - elapsed
            print(f"Estimated Remaining: {timedelta(seconds=int(remaining_time))}")
        
        print("-" * 80)
        print("Chunk Progress:")
        print("-" * 80)
        
        # Show individual chunk progress
        for chunk_id in sorted(progress_data.keys()):
            data = progress_data[chunk_id]
            status = "✓ Complete" if data.get('completed', False) else f"{data.get('progress', 0)}%"
            positions = data.get('positions', 0)
            chunk_elapsed = data.get('elapsed', 0)
            
            print(f"Chunk {chunk_id:3d}: [{status:>11}] {positions:>6,} positions | {timedelta(seconds=int(chunk_elapsed))}")
        
        print("=" * 80)
    
    def run_parallel_generation(self, num_chunks: int, movetime_ms: int, parallel_workers: int):
        """Run parallel chunk generation"""
        start_time = time.time()
        start_chunk_id = self.find_next_chunk_id()
        
        # Create queue for progress updates
        progress_queue = Queue()
        progress_data = {}
        
        # Create list of chunk IDs to process
        chunk_ids = list(range(start_chunk_id, start_chunk_id + num_chunks))
        
        # Process chunks in batches
        processes = []
        chunk_index = 0
        active_processes = 0
        
        print(f"\nStarting generation of {num_chunks} chunks with {parallel_workers} parallel workers...")
        time.sleep(1)
        
        try:
            while chunk_index < len(chunk_ids) or active_processes > 0:
                # Start new processes if we have capacity and chunks remaining
                while active_processes < parallel_workers and chunk_index < len(chunk_ids):
                    chunk_id = chunk_ids[chunk_index]
                    p = Process(target=worker_process, 
                              args=(self.stockfish_path, movetime_ms, chunk_id, progress_queue))
                    p.start()
                    processes.append(p)
                    progress_data[chunk_id] = {'progress': 0, 'positions': 0}
                    chunk_index += 1
                    active_processes += 1
                
                # Check for progress updates
                while not progress_queue.empty():
                    update = progress_queue.get()
                    chunk_id = update['chunk_id']
                    progress_data[chunk_id] = update
                    
                    # If chunk completed, reduce active count
                    if update.get('completed', False):
                        active_processes -= 1
                    
                    # Update display
                    self.print_progress(progress_data, num_chunks, start_time, 
                                      movetime_ms, parallel_workers)
                
                # Small delay to prevent CPU spinning
                time.sleep(0.1)
            
            # Wait for all processes to complete
            for p in processes:
                p.join()
            
            # Final update
            self.print_progress(progress_data, num_chunks, start_time, 
                              movetime_ms, parallel_workers)
            
            # Summary
            total_positions = sum(p.get('positions', 0) for p in progress_data.values())
            total_time = time.time() - start_time
            
            print("\n" + "=" * 80)
            print("Generation Complete!")
            print("=" * 80)
            print(f"Total chunks generated: {num_chunks}")
            print(f"Total positions generated: {total_positions:,}")
            print(f"Average positions per chunk: {total_positions / num_chunks:.1f}")
            print(f"Total time: {timedelta(seconds=int(total_time))}")
            print(f"Data saved to: {self.data_dir}/")
            print("=" * 80)
            
        except KeyboardInterrupt:
            print("\n\nGeneration interrupted by user.")
            print("Terminating all processes...")
            for p in processes:
                if p.is_alive():
                    p.terminate()
            for p in processes:
                p.join()
            print("All processes terminated.")
        except Exception as e:
            print(f"\nError during generation: {e}")
            import traceback
            traceback.print_exc()
            # Clean up processes
            for p in processes:
                if p.is_alive():
                    p.terminate()
    
    def interactive_setup(self) -> Tuple[int, int, int]:
        """Interactive setup to get parameters from user"""
        self.clear_console()
        print("=" * 80)
        print("Chess Position Generator - Setup")
        print("=" * 80)
        
        # Show existing chunks info
        existing_chunks = list(self.data_dir.glob('chunk_*.csv'))
        if existing_chunks:
            print(f"Found {len(existing_chunks)} existing chunk(s) in {self.data_dir}/")
            print(f"Next chunk will start from ID: {self.find_next_chunk_id()}")
            print()
        
        print("Each chunk will contain 100,000 positions")
        print()
        
        # Get number of chunks
        while True:
            try:
                num_chunks = int(input("Enter number of chunks to generate: "))
                if num_chunks > 0:
                    break
                else:
                    print("Please enter a positive number.")
            except ValueError:
                print("Invalid input. Please enter a number.")
        
        # Get move time
        while True:
            try:
                movetime_ms = int(input("Enter move time in milliseconds (e.g., 10, 50, 100): "))
                if movetime_ms > 0:
                    break
                else:
                    print("Please enter a positive number.")
            except ValueError:
                print("Invalid input. Please enter a number.")
        
        # Get parallel execution count
        max_parallel = max(1, psutil.cpu_count() // 2)
        print(f"\nParallel execution (recommended max: {max_parallel})")
        while True:
            try:
                parallel_input = input(f"Enter number of parallel workers (default 1, max {max_parallel}): ").strip()
                if parallel_input == "":
                    parallel_workers = 1
                else:
                    parallel_workers = int(parallel_input)
                
                if 1 <= parallel_workers <= max_parallel:
                    break
                else:
                    print(f"Please enter a number between 1 and {max_parallel}.")
            except ValueError:
                print("Invalid input. Please enter a number.")
        
        # Show summary
        print("\n" + "=" * 80)
        print("Generation Summary")
        print("=" * 80)
        print(f"Chunks to generate: {num_chunks}")
        print(f"Positions per chunk: 100,000")
        print(f"Total positions: {num_chunks * 100000:,}")
        print(f"Move time per evaluation: {movetime_ms}ms")
        print(f"Parallel workers: {parallel_workers}")
        print(f"Starting chunk ID: {self.find_next_chunk_id()}")
        
        # Estimate duration (movetime * positions + 10% buffer)
        total_positions = num_chunks * 100000
        estimated_ms = total_positions * movetime_ms * 1.1  # 10% buffer
        # Divide by parallel workers for parallel execution
        estimated_ms = estimated_ms / parallel_workers
        duration = timedelta(milliseconds=estimated_ms)
        
        hours = int(duration.total_seconds() // 3600)
        minutes = int((duration.total_seconds() % 3600) // 60)
        seconds = int(duration.total_seconds() % 60)
        
        if hours > 0:
            duration_str = f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            duration_str = f"{minutes}m {seconds}s"
        else:
            duration_str = f"{seconds}s"
        
        print(f"Estimated duration: {duration_str}")
        print("=" * 80)
        
        # Confirm
        confirm = input("\nProceed with generation? (y/n): ").strip().lower()
        if confirm != 'y':
            print("Generation cancelled.")
            return 0, 0, 0
        
        return num_chunks, movetime_ms, parallel_workers


def main():
    """Main function"""
    # Configuration
    STOCKFISH_PATH = "engines/stockfish.exe"  # Path to stockfish executable
    
    # Create parallel generator
    generator = ParallelChessGenerator(STOCKFISH_PATH)
    
    # Interactive setup
    num_chunks, movetime_ms, parallel_workers = generator.interactive_setup()
    
    if num_chunks == 0:
        return
    
    # Run parallel generation
    generator.run_parallel_generation(num_chunks, movetime_ms, parallel_workers)


if __name__ == "__main__":
    main()