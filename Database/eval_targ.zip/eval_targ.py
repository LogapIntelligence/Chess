# ===== PYTHON INFERENCE CODE =====

import numpy as np
import struct
import json

class ChessEvaluator:
    """Lightweight chess position evaluator for inference"""
    
    PIECES = {
        'P': 1, 'N': 2, 'B': 3, 'R': 4, 'Q': 5, 'K': 6,
        'p': -1, 'n': -2, 'b': -3, 'r': -4, 'q': -5, 'k': -6
    }
    
    def __init__(self, model_path: str):
        """Load model from binary file"""
        if model_path.endswith('.json'):
            self._load_json(model_path)
        else:
            self._load_binary(model_path)
    
    def _load_binary(self, filepath: str):
        """Load model from ultra-compact binary format"""
        with open(filepath, 'rb') as f:
            # Read architecture
            self.input_size = struct.unpack('I', f.read(4))[0]
            num_hidden = struct.unpack('I', f.read(4))[0]
            self.hidden_sizes = []
            for _ in range(num_hidden):
                self.hidden_sizes.append(struct.unpack('I', f.read(4))[0])
            
            # Read weights
            self.weights = []
            self.biases = []
            
            # Input -> Hidden[0]
            prev_size = self.input_size
            for hidden_size in self.hidden_sizes:
                # Weight matrix
                w_size = prev_size * hidden_size
                w_data = struct.unpack(f'{w_size}f', f.read(w_size * 4))
                self.weights.append(np.array(w_data).reshape(prev_size, hidden_size))
                
                # Bias vector
                b_data = struct.unpack(f'{hidden_size}f', f.read(hidden_size * 4))
                self.biases.append(np.array(b_data))
                
                prev_size = hidden_size
            
            # Last hidden -> Output
            w_data = struct.unpack(f'{prev_size}f', f.read(prev_size * 4))
            self.weights.append(np.array(w_data).reshape(prev_size, 1))
            b_data = struct.unpack('f', f.read(4))
            self.biases.append(np.array(b_data))
    
    def _load_json(self, filepath: str):
        """Load model from JSON format"""
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        self.input_size = data['architecture']['input_size']
        self.hidden_sizes = data['architecture']['hidden_sizes']
        
        self.weights = []
        self.biases = []
        
        for layer_data in data['weights']:
            if 'hidden' in layer_data['name'] or 'output' in layer_data['name']:
                self.weights.append(np.array(layer_data['weights'][0]))
                self.biases.append(np.array(layer_data['weights'][1]))
    
    def encode_fen(self, fen: str) -> np.ndarray:
        """Convert FEN string to neural network input"""
        parts = fen.split()
        board_str = parts[0]
        
        # Board representation
        board = np.zeros(64, dtype=np.float32)
        row, col = 0, 0
        
        for char in board_str:
            if char == '/':
                row += 1
                col = 0
            elif char.isdigit():
                col += int(char)
            else:
                idx = row * 8 + col
                board[idx] = self.PIECES.get(char, 0) / 6.0
                col += 1
        
        # Additional features
        features = []
        
        # Active color
        if len(parts) > 1:
            features.append(1.0 if parts[1] == 'w' else -1.0)
        else:
            features.append(0.0)
        
        # Castling rights
        if len(parts) > 2:
            castling = parts[2]
            features.extend([
                1.0 if 'K' in castling else 0.0,
                1.0 if 'Q' in castling else 0.0,
                1.0 if 'k' in castling else 0.0,
                1.0 if 'q' in castling else 0.0
            ])
        else:
            features.extend([0.0, 0.0, 0.0, 0.0])
        
        # En passant
        if len(parts) > 3 and parts[3] != '-':
            file_idx = ord(parts[3][0]) - ord('a')
            features.append(file_idx / 7.0)
        else:
            features.append(-1.0)
        
        return np.concatenate([board, features])
    
    def relu(self, x):
        """ReLU activation function"""
        return np.maximum(0, x)
    
    def tanh(self, x):
        """Tanh activation function"""
        return np.tanh(x)
    
    def evaluate(self, fen: str) -> float:
        """Evaluate a chess position from FEN string"""
        # Encode position
        x = self.encode_fen(fen)
        
        # Forward pass through network
        for i in range(len(self.weights) - 1):
            x = np.dot(x, self.weights[i]) + self.biases[i]
            x = self.relu(x)
        
        # Output layer
        x = np.dot(x, self.weights[-1]) + self.biases[-1]
        x = self.tanh(x)
        
        # Convert from normalized [-1, 1] to centipawns
        return float(x[0] * 1000)


# ===== C# INFERENCE CODE =====

"""
using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;

public class ChessEvaluator
{
    private static readonly Dictionary<char, float> PIECES = new Dictionary<char, float>
    {
        {'P', 1f/6f}, {'N', 2f/6f}, {'B', 3f/6f}, {'R', 4f/6f}, {'Q', 5f/6f}, {'K', 6f/6f},
        {'p', -1f/6f}, {'n', -2f/6f}, {'b', -3f/6f}, {'r', -4f/6f}, {'q', -5f/6f}, {'k', -6f/6f}
    };
    
    private int inputSize;
    private List<int> hiddenSizes;
    private List<float[,]> weights;
    private List<float[]> biases;
    
    public ChessEvaluator(string modelPath)
    {
        LoadBinary(modelPath);
    }
    
    private void LoadBinary(string filepath)
    {
        weights = new List<float[,]>();
        biases = new List<float[]>();
        hiddenSizes = new List<int>();
        
        using (var reader = new BinaryReader(File.Open(filepath, FileMode.Open)))
        {
            // Read architecture
            inputSize = reader.ReadInt32();
            int numHidden = reader.ReadInt32();
            
            for (int i = 0; i < numHidden; i++)
            {
                hiddenSizes.Add(reader.ReadInt32());
            }
            
            // Read weights
            int prevSize = inputSize;
            foreach (int hiddenSize in hiddenSizes)
            {
                // Weight matrix
                var w = new float[prevSize, hiddenSize];
                for (int j = 0; j < prevSize; j++)
                {
                    for (int k = 0; k < hiddenSize; k++)
                    {
                        w[j, k] = reader.ReadSingle();
                    }
                }
                weights.Add(w);
                
                // Bias vector
                var b = new float[hiddenSize];
                for (int j = 0; j < hiddenSize; j++)
                {
                    b[j] = reader.ReadSingle();
                }
                biases.Add(b);
                
                prevSize = hiddenSize;
            }
            
            // Output layer
            var wOut = new float[prevSize, 1];
            for (int j = 0; j < prevSize; j++)
            {
                wOut[j, 0] = reader.ReadSingle();
            }
            weights.Add(wOut);
            
            var bOut = new float[1];
            bOut[0] = reader.ReadSingle();
            biases.Add(bOut);
        }
    }
    
    private float[] EncodeFEN(string fen)
    {
        string[] parts = fen.Split(' ');
        string boardStr = parts[0];
        
        // Initialize features array
        float[] features = new float[70]; // 64 board + 6 features
        
        // Parse board
        int row = 0, col = 0;
        foreach (char c in boardStr)
        {
            if (c == '/')
            {
                row++;
                col = 0;
            }
            else if (char.IsDigit(c))
            {
                col += c - '0';
            }
            else
            {
                int idx = row * 8 + col;
                if (PIECES.ContainsKey(c))
                {
                    features[idx] = PIECES[c];
                }
                col++;
            }
        }
        
        // Active color
        features[64] = (parts.Length > 1 && parts[1] == "w") ? 1f : -1f;
        
        // Castling rights
        if (parts.Length > 2)
        {
            string castling = parts[2];
            features[65] = castling.Contains('K') ? 1f : 0f;
            features[66] = castling.Contains('Q') ? 1f : 0f;
            features[67] = castling.Contains('k') ? 1f : 0f;
            features[68] = castling.Contains('q') ? 1f : 0f;
        }
        
        // En passant
        if (parts.Length > 3 && parts[3] != "-")
        {
            int fileIdx = parts[3][0] - 'a';
            features[69] = fileIdx / 7f;
        }
        else
        {
            features[69] = -1f;
        }
        
        return features;
    }
    
    private float ReLU(float x)
    {
        return Math.Max(0, x);
    }
    
    public float Evaluate(string fen)
    {
        float[] x = EncodeFEN(fen);
        
        // Forward pass through network
        for (int layer = 0; layer < weights.Count - 1; layer++)
        {
            float[] newX = new float[weights[layer].GetLength(1)];
            
            // Matrix multiplication
            for (int j = 0; j < weights[layer].GetLength(1); j++)
            {
                float sum = biases[layer][j];
                for (int i = 0; i < weights[layer].GetLength(0); i++)
                {
                    sum += x[i] * weights[layer][i, j];
                }
                newX[j] = ReLU(sum);
            }
            
            x = newX;
        }
        
        // Output layer
        float output = biases[biases.Count - 1][0];
        for (int i = 0; i < x.Length; i++)
        {
            output += x[i] * weights[weights.Count - 1][i, 0];
        }
        
        // Tanh activation and convert to centipawns
        return (float)Math.Tanh(output) * 1000f;
    }
}

// Example usage:
class Program
{
    static void Main()
    {
        var evaluator = new ChessEvaluator("chess_model.bin");
        
        string startPos = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
        float eval = evaluator.Evaluate(startPos);
        
        Console.WriteLine($"Position: {startPos}");
        Console.WriteLine($"Evaluation: {eval:F0} centipawns");
    }
}
"""

# ===== USAGE EXAMPLES =====

# Python usage:
if __name__ == "__main__":
    # Load the model
    evaluator = ChessEvaluator("models/chess_model.bin")
    
    # Test positions
    test_positions = [
        "rnbqkb1r/pppp1ppp/5n2/4P3/8/8/PPPPP1PP/RNBQKBNR w KQkq - 1 3",  # Starting position
    ]
    
    print("Chess Position Evaluations:")
    print("-" * 60)
    
    for fen in test_positions:
        eval_score = evaluator.evaluate(fen)
        print(f"FEN: {fen}")
        print(f"Evaluation: {eval_score:+.0f} centipawns")
        print("-" * 60)