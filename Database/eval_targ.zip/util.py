import numpy as np
import struct
import os
from typing import Dict, List, Tuple
import gzip
import json
import csv
import pandas as pd

class ModelOptimizer:
    """Utilities for optimizing and managing chess evaluation models"""
    
    @staticmethod
    def analyze_model_size(model_path: str) -> Dict:
        """Analyze model size and parameter distribution"""
        if model_path.endswith('.bin'):
            return ModelOptimizer._analyze_binary(model_path)
        elif model_path.endswith('.json'):
            return ModelOptimizer._analyze_json(model_path)
        else:
            raise ValueError("Unsupported model format")
    
    @staticmethod
    def _analyze_binary(filepath: str) -> Dict:
        """Analyze binary model file"""
        file_size = os.path.getsize(filepath)
        
        with open(filepath, 'rb') as f:
            # Read architecture
            input_size = struct.unpack('I', f.read(4))[0]
            num_hidden = struct.unpack('I', f.read(4))[0]
            hidden_sizes = []
            for _ in range(num_hidden):
                hidden_sizes.append(struct.unpack('I', f.read(4))[0])
            
            # Calculate parameters
            total_params = 0
            layer_params = []
            
            prev_size = input_size
            for i, hidden_size in enumerate(hidden_sizes):
                weights = prev_size * hidden_size
                biases = hidden_size
                layer_params.append({
                    'layer': f'hidden_{i}',
                    'weights': weights,
                    'biases': biases,
                    'total': weights + biases
                })
                total_params += weights + biases
                prev_size = hidden_size
            
            # Output layer
            weights = prev_size * 1
            biases = 1
            layer_params.append({
                'layer': 'output',
                'weights': weights,
                'biases': biases,
                'total': weights + biases
            })
            total_params += weights + biases
        
        return {
            'file_size_bytes': file_size,
            'file_size_mb': file_size / (1024 * 1024),
            'total_parameters': total_params,
            'architecture': {
                'input_size': input_size,
                'hidden_sizes': hidden_sizes
            },
            'layer_details': layer_params,
            'theoretical_size_mb': (total_params * 4) / (1024 * 1024)
        }
    
    @staticmethod
    def _analyze_json(filepath: str) -> Dict:
        """Analyze JSON model file"""
        file_size = os.path.getsize(filepath)
        
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        architecture = data['architecture']
        total_params = 0
        layer_params = []
        
        for layer_data in data['weights']:
            if 'weights' in layer_data:
                weights_shape = np.array(layer_data['weights'][0]).shape
                biases_shape = np.array(layer_data['weights'][1]).shape
                
                weights_count = np.prod(weights_shape)
                biases_count = np.prod(biases_shape)
                
                layer_params.append({
                    'layer': layer_data['name'],
                    'weights': weights_count,
                    'biases': biases_count,
                    'total': weights_count + biases_count
                })
                total_params += weights_count + biases_count
        
        return {
            'file_size_bytes': file_size,
            'file_size_mb': file_size / (1024 * 1024),
            'total_parameters': total_params,
            'architecture': architecture,
            'layer_details': layer_params,
            'theoretical_size_mb': (total_params * 4) / (1024 * 1024)
        }
    
    @staticmethod
    def compress_model(model_path: str, output_path: str = None):
        """Compress model using gzip"""
        if output_path is None:
            output_path = model_path + '.gz'
        
        with open(model_path, 'rb') as f_in:
            with gzip.open(output_path, 'wb') as f_out:
                f_out.writelines(f_in)
        
        original_size = os.path.getsize(model_path)
        compressed_size = os.path.getsize(output_path)
        
        print(f"Compression complete:")
        print(f"Original: {original_size / 1024:.2f} KB")
        print(f"Compressed: {compressed_size / 1024:.2f} KB")
        print(f"Compression ratio: {compressed_size / original_size:.2%}")
        
        return output_path
    
    @staticmethod
    def quantize_model(model_path: str, output_path: str = None, bits: int = 8):
        """Quantize model weights to reduce size (int8 or int16)"""
        if output_path is None:
            output_path = model_path.replace('.bin', f'_q{bits}.bin')
        
        # Read original model
        with open(model_path, 'rb') as f:
            # Read architecture
            header = f.read(4)  # input_size
            num_hidden_bytes = f.read(4)
            num_hidden = struct.unpack('I', num_hidden_bytes)[0]
            
            hidden_sizes_bytes = f.read(4 * num_hidden)
            
            # Read all weights
            weights_data = f.read()
        
        # Parse weights as float32
        num_floats = len(weights_data) // 4
        weights = struct.unpack(f'{num_floats}f', weights_data)
        weights_array = np.array(weights, dtype=np.float32)
        
        # Quantize
        if bits == 8:
            # Quantize to int8
            scale = 127.0 / np.max(np.abs(weights_array))
            quantized = np.round(weights_array * scale).astype(np.int8)
            dtype_char = 'b'  # signed char
        elif bits == 16:
            # Quantize to int16
            scale = 32767.0 / np.max(np.abs(weights_array))
            quantized = np.round(weights_array * scale).astype(np.int16)
            dtype_char = 'h'  # short
        else:
            raise ValueError("Only 8-bit and 16-bit quantization supported")
        
        # Write quantized model
        with open(output_path, 'wb') as f:
            # Write header
            f.write(header)
            f.write(num_hidden_bytes)
            f.write(hidden_sizes_bytes)
            
            # Write scale factor
            f.write(struct.pack('f', scale))
            
            # Write quantized weights
            f.write(struct.pack(f'{len(quantized)}{dtype_char}', *quantized))
        
        original_size = os.path.getsize(model_path)
        quantized_size = os.path.getsize(output_path)
        
        print(f"Quantization complete ({bits}-bit):")
        print(f"Original: {original_size / 1024:.2f} KB")
        print(f"Quantized: {quantized_size / 1024:.2f} KB")
        print(f"Size reduction: {(1 - quantized_size / original_size):.1%}")
        
        return output_path

class DataProcessor:
    """Utilities for processing chess position data"""
    
    @staticmethod
    def convert_txt_to_csv(txt_file: str, csv_file: str):
        """Convert text format data to CSV format"""
        with open(txt_file, 'r') as f_in, open(csv_file, 'w', newline='') as f_out:
            writer = csv.writer(f_out)
            writer.writerow(['Evaluation', 'Fen'])  # Header
            
            for line in f_in:
                line = line.strip()
                if not line:
                    continue
                
                parts = line.split(' ', 1)
                if len(parts) == 2:
                    writer.writerow([parts[0], parts[1]])
        
        print(f"Converted {txt_file} to {csv_file}")
    
    @staticmethod
    def convert_csv_to_txt(csv_file: str, txt_file: str):
        """Convert CSV format data to text format"""
        df = pd.read_csv(csv_file)
        
        with open(txt_file, 'w') as f:
            for _, row in df.iterrows():
                f.write(f"{row['Evaluation']} {row['Fen']}\n")
        
        print(f"Converted {csv_file} to {txt_file}")
    
    @staticmethod
    def validate_csv_file(filepath: str) -> Tuple[int, List[str]]:
        """Validate CSV training data file and report issues"""
        issues = []
        valid_count = 0
        total_count = 0
        
        try:
            df = pd.read_csv(filepath)
            
            # Check required columns
            if 'Evaluation' not in df.columns or 'Fen' not in df.columns:
                issues.append("Missing required columns: 'Evaluation' and/or 'Fen'")
                return 0, issues
            
            for idx, row in df.iterrows():
                total_count += 1
                
                # Check evaluation
                try:
                    eval_score = float(row['Evaluation'])
                    if abs(eval_score) > 100000:
                        issues.append(f"Row {idx+2}: Evaluation seems too large ({eval_score})")
                except (ValueError, TypeError):
                    issues.append(f"Row {idx+2}: Invalid evaluation score")
                    continue
                
                # Validate FEN
                try:
                    fen_parts = str(row['Fen']).split()
                    if len(fen_parts) < 1:
                        issues.append(f"Row {idx+2}: Invalid FEN string")
                        continue
                    
                    # Basic FEN validation
                    board = fen_parts[0]
                    rows = board.split('/')
                    if len(rows) != 8:
                        issues.append(f"Row {idx+2}: FEN should have 8 rows")
                        continue
                    
                    valid_count += 1
                except Exception as e:
                    issues.append(f"Row {idx+2}: Error processing FEN - {e}")
                    
        except Exception as e:
            issues.append(f"Error reading CSV file: {e}")
        
        print(f"CSV validation complete:")
        print(f"Total rows: {total_count}")
        print(f"Valid positions: {valid_count}")
        print(f"Issues found: {len(issues)}")
        
        if issues:
            print("\nFirst 10 issues:")
            for issue in issues[:10]:
                print(f"  - {issue}")
        
        return valid_count, issues
    
    @staticmethod
    def validate_data_file(filepath: str) -> Tuple[int, List[str]]:
        """Validate training data file (auto-detects format)"""
        if filepath.endswith('.csv'):
            return DataProcessor.validate_csv_file(filepath)
        else:
            return DataProcessor._validate_txt_file(filepath)
    
    @staticmethod
    def _validate_txt_file(filepath: str) -> Tuple[int, List[str]]:
        """Validate text training data file and report issues"""
        issues = []
        valid_count = 0
        total_count = 0
        
        with open(filepath, 'r') as f:
            for line_num, line in enumerate(f, 1):
                total_count += 1
                line = line.strip()
                
                if not line:
                    continue
                
                parts = line.split(' ', 1)
                if len(parts) != 2:
                    issues.append(f"Line {line_num}: Invalid format (expected '<eval> <fen>')")
                    continue
                
                # Check evaluation
                try:
                    eval_score = float(parts[0])
                    if abs(eval_score) > 100000:
                        issues.append(f"Line {line_num}: Evaluation seems too large ({eval_score})")
                except ValueError:
                    issues.append(f"Line {line_num}: Invalid evaluation score")
                    continue
                
                # Validate FEN
                fen_parts = parts[1].split()
                if len(fen_parts) < 1:
                    issues.append(f"Line {line_num}: Invalid FEN string")
                    continue
                
                # Basic FEN validation
                board = fen_parts[0]
                rows = board.split('/')
                if len(rows) != 8:
                    issues.append(f"Line {line_num}: FEN should have 8 rows")
                    continue
                
                valid_count += 1
        
        print(f"Data validation complete:")
        print(f"Total lines: {total_count}")
        print(f"Valid positions: {valid_count}")
        print(f"Issues found: {len(issues)}")
        
        if issues:
            print("\nFirst 10 issues:")
            for issue in issues[:10]:
                print(f"  - {issue}")
        
        return valid_count, issues
    
    @staticmethod
    def merge_data_files(input_files: List[str], output_file: str, format: str = 'csv'):
        """Merge multiple data files into one"""
        all_data = []
        
        for file in input_files:
            if file.endswith('.csv'):
                df = pd.read_csv(file)
                for _, row in df.iterrows():
                    all_data.append((row['Evaluation'], row['Fen']))
            else:
                with open(file, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            parts = line.split(' ', 1)
                            if len(parts) == 2:
                                all_data.append((parts[0], parts[1]))
        
        # Write output
        if format == 'csv':
            with open(output_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Evaluation', 'Fen'])
                writer.writerows(all_data)
        else:
            with open(output_file, 'w') as f:
                for eval_score, fen in all_data:
                    f.write(f"{eval_score} {fen}\n")
        
        print(f"Merged {len(input_files)} files into {output_file}")
        print(f"Total positions: {len(all_data)}")
    
    @staticmethod
    def augment_data(input_file: str, output_file: str, augmentations: List[str] = ['flip']):
        """Augment training data with transformations"""
        augmented_count = 0
        
        # Determine file format
        is_csv = input_file.endswith('.csv')
        
        if is_csv:
            df = pd.read_csv(input_file)
            augmented_rows = []
            
            for _, row in df.iterrows():
                # Add original
                augmented_rows.append([row['Evaluation'], row['Fen']])
                
                # Apply augmentations
                if 'flip' in augmentations:
                    flipped_fen = DataProcessor._flip_fen(row['Fen'])
                    if flipped_fen:
                        augmented_rows.append([row['Evaluation'], flipped_fen])
                        augmented_count += 1
            
            # Write augmented CSV
            with open(output_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['Evaluation', 'Fen'])
                writer.writerows(augmented_rows)
        else:
            with open(input_file, 'r') as f_in, open(output_file, 'w') as f_out:
                for line in f_in:
                    line = line.strip()
                    if not line:
                        continue
                    
                    # Write original
                    f_out.write(line + '\n')
                    
                    parts = line.split(' ', 1)
                    if len(parts) != 2:
                        continue
                    
                    eval_score = float(parts[0])
                    fen = parts[1]
                    
                    # Apply augmentations
                    if 'flip' in augmentations:
                        # Flip the board (mirror horizontally)
                        flipped_fen = DataProcessor._flip_fen(fen)
                        if flipped_fen:
                            f_out.write(f"{eval_score} {flipped_fen}\n")
                            augmented_count += 1
        
        print(f"Data augmentation complete:")
        print(f"Original positions: {augmented_count}")
        print(f"Total positions: {augmented_count * 2}")
    
    @staticmethod
    def _flip_fen(fen: str) -> str:
        """Flip FEN position horizontally"""
        parts = fen.split()
        if not parts:
            return None
        
        board = parts[0]
        rows = board.split('/')
        
        flipped_rows = []
        for row in rows:
            flipped_row = ""
            for char in row:
                if char.isdigit():
                    flipped_row += char
                else:
                    # Flip file (a-h becomes h-a)
                    flipped_row = char + flipped_row
            flipped_rows.append(flipped_row)
        
        flipped_board = '/'.join(flipped_rows)
        
        # Reconstruct FEN
        result = flipped_board
        if len(parts) > 1:
            result += ' ' + ' '.join(parts[1:])
        
        return result

# Example usage
if __name__ == "__main__":
    print("Chess Model Utilities\n")
    
    # Analyze model size
    print("1. Model Analysis:")
    print("-" * 50)
    
    if os.path.exists("chess_model.bin"):
        analysis = ModelOptimizer.analyze_model_size("chess_model.bin")
        print(f"File size: {analysis['file_size_mb']:.2f} MB")
        print(f"Total parameters: {analysis['total_parameters']:,}")
        print(f"Architecture: {analysis['architecture']}")
        print("\nLayer breakdown:")
        for layer in analysis['layer_details']:
            print(f"  {layer['layer']}: {layer['total']:,} params "
                  f"({layer['weights']:,} weights, {layer['biases']:,} biases)")
    
    # Validate data
    print("\n2. Data Validation:")
    print("-" * 50)
    
    # Check for CSV file first
    if os.path.exists("data.csv"):
        valid_count, issues = DataProcessor.validate_data_file("data.csv")
        print(f"Validation ratio: {valid_count / (valid_count + len(issues)):.1%}")
    elif os.path.exists("data.txt"):
        valid_count, issues = DataProcessor.validate_data_file("data.txt")
        print(f"Validation ratio: {valid_count / (valid_count + len(issues)):.1%}")
    
    # Format conversion example
    print("\n3. Format Conversion:")
    print("-" * 50)
    
    if os.path.exists("data.txt") and not os.path.exists("data.csv"):
        DataProcessor.convert_txt_to_csv("data.txt", "data.csv")
    elif os.path.exists("data.csv") and not os.path.exists("data.txt"):
        DataProcessor.convert_csv_to_txt("data.csv", "data.txt")
    
    # Compression example
    print("\n4. Model Compression:")
    print("-" * 50)
    
    if os.path.exists("chess_model.bin"):
        # Standard compression
        ModelOptimizer.compress_model("chess_model.bin")
        
        # Quantization
        ModelOptimizer.quantize_model("chess_model.bin", bits=8)
    
    # Data merging example
    print("\n5. Data Management:")
    print("-" * 50)
    print("Example: Merge multiple data files")
    print("DataProcessor.merge_data_files(['data1.csv', 'data2.txt'], 'merged.csv')")
    
    print("\nUtilities demonstration complete!")