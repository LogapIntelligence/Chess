import numpy as np
import pandas as pd
import time
from typing import List, Tuple, Dict
import os
import struct
import json

class ChessEvaluator:
    """Lightweight chess position evaluator for inference"""
    
    PIECES = {
        'P': 1, 'N': 2, 'B': 3, 'R': 4, 'Q': 5, 'K': 6,
        'p': -1, 'n': -2, 'b': -3, 'r': -4, 'q': -5, 'k': -6
    }
    
    def __init__(self, model_path: str):
        """Load model from binary file"""
        if model_path.endswith('.json'):
            self._load_json(model_path)
        else:
            self._load_binary(model_path)
    
    def _load_binary(self, filepath: str):
        """Load model from ultra-compact binary format"""
        with open(filepath, 'rb') as f:
            # Read architecture
            self.input_size = struct.unpack('I', f.read(4))[0]
            num_hidden = struct.unpack('I', f.read(4))[0]
            self.hidden_sizes = []
            for _ in range(num_hidden):
                self.hidden_sizes.append(struct.unpack('I', f.read(4))[0])
            
            # Read weights
            self.weights = []
            self.biases = []
            
            # Input -> Hidden[0]
            prev_size = self.input_size
            for hidden_size in self.hidden_sizes:
                # Weight matrix
                w_size = prev_size * hidden_size
                w_data = struct.unpack(f'{w_size}f', f.read(w_size * 4))
                self.weights.append(np.array(w_data).reshape(prev_size, hidden_size))
                
                # Bias vector
                b_data = struct.unpack(f'{hidden_size}f', f.read(hidden_size * 4))
                self.biases.append(np.array(b_data))
                
                prev_size = hidden_size
            
            # Last hidden -> Output
            w_data = struct.unpack(f'{prev_size}f', f.read(prev_size * 4))
            self.weights.append(np.array(w_data).reshape(prev_size, 1))
            b_data = struct.unpack('f', f.read(4))
            self.biases.append(np.array(b_data))
    
    def _load_json(self, filepath: str):
        """Load model from JSON format"""
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        self.input_size = data['architecture']['input_size']
        self.hidden_sizes = data['architecture']['hidden_sizes']
        
        self.weights = []
        self.biases = []
        
        for layer_data in data['weights']:
            if 'hidden' in layer_data['name'] or 'output' in layer_data['name']:
                self.weights.append(np.array(layer_data['weights'][0]))
                self.biases.append(np.array(layer_data['weights'][1]))
    
    def encode_fen(self, fen: str) -> np.ndarray:
        """Convert FEN string to neural network input"""
        parts = fen.split()
        board_str = parts[0]
        
        # Board representation
        board = np.zeros(64, dtype=np.float32)
        row, col = 0, 0
        
        for char in board_str:
            if char == '/':
                row += 1
                col = 0
            elif char.isdigit():
                col += int(char)
            else:
                idx = row * 8 + col
                board[idx] = self.PIECES.get(char, 0) / 6.0
                col += 1
        
        # Additional features
        features = []
        
        # Active color
        if len(parts) > 1:
            features.append(1.0 if parts[1] == 'w' else -1.0)
        else:
            features.append(0.0)
        
        # Castling rights
        if len(parts) > 2:
            castling = parts[2]
            features.extend([
                1.0 if 'K' in castling else 0.0,
                1.0 if 'Q' in castling else 0.0,
                1.0 if 'k' in castling else 0.0,
                1.0 if 'q' in castling else 0.0
            ])
        else:
            features.extend([0.0, 0.0, 0.0, 0.0])
        
        # En passant
        if len(parts) > 3 and parts[3] != '-':
            file_idx = ord(parts[3][0]) - ord('a')
            features.append(file_idx / 7.0)
        else:
            features.append(-1.0)
        
        return np.concatenate([board, features])
    
    def relu(self, x):
        """ReLU activation function"""
        return np.maximum(0, x)
    
    def tanh(self, x):
        """Tanh activation function"""
        return np.tanh(x)
    
    def evaluate(self, fen: str) -> float:
        """Evaluate a chess position from FEN string"""
        # Encode position
        x = self.encode_fen(fen)
        
        # Forward pass through network
        for i in range(len(self.weights) - 1):
            x = np.dot(x, self.weights[i]) + self.biases[i]
            x = self.relu(x)
        
        # Output layer
        x = np.dot(x, self.weights[-1]) + self.biases[-1]
        x = self.tanh(x)
        
        # Convert from normalized [-1, 1] to centipawns
        return float(x[0] * 1000)


# ===== TEST SUITE =====

class ChessEvaluatorTester:
    """Test suite for chess position evaluator"""
    
    # Define centipawn ranges for evaluation categories
    CP_RANGES = [
        (0, 50, "Slight advantage"),
        (50, 100, "Clear advantage"),
        (100, 200, "Strong advantage"),
        (200, 300, "Decisive advantage"),
        (300, 500, "Winning advantage"),
        (500, float('inf'), "Overwhelming advantage")
    ]
    
    def __init__(self, model_path: str, test_data_path: str):
        """Initialize tester with model and test data"""
        self.evaluator = ChessEvaluator(model_path)
        self.test_data = pd.read_csv(test_data_path)
        self.results = []
        
    def run_evaluations(self) -> List[Dict]:
        """Run evaluations on all test positions"""
        results = []
        
        for idx, row in self.test_data.iterrows():
            expected_cp = row['cp']
            fen = row['fen']
            
            # Time the evaluation
            start_time = time.time()
            predicted_cp = self.evaluator.evaluate(fen)
            eval_time = time.time() - start_time
            
            # Calculate error
            error = predicted_cp - expected_cp
            abs_error = abs(error)
            
            results.append({
                'fen': fen,
                'expected_cp': expected_cp,
                'predicted_cp': predicted_cp,
                'error': error,
                'abs_error': abs_error,
                'eval_time': eval_time
            })
            
        self.results = results
        return results
    
    def get_cp_range(self, cp_value: float) -> str:
        """Get the evaluation category for a centipawn value"""
        abs_cp = abs(cp_value)
        if abs_cp == 0:
            return "Even position"
        
        for min_cp, max_cp, category in self.CP_RANGES:
            if min_cp < abs_cp <= max_cp:
                return category
        return "Overwhelming advantage"
    
    def analyze_accuracy_by_range(self) -> Dict:
        """Analyze accuracy within different centipawn ranges"""
        range_analysis = {}
        
        # Group results by expected CP range
        for min_cp, max_cp, category in [(0, 0, "Even position")] + self.CP_RANGES:
            range_results = []
            
            for result in self.results:
                expected_abs = abs(result['expected_cp'])
                
                if min_cp == 0 and max_cp == 0 and expected_abs == 0:
                    range_results.append(result)
                elif min_cp < expected_abs <= max_cp:
                    range_results.append(result)
            
            if range_results:
                errors = [r['abs_error'] for r in range_results]
                range_analysis[category] = {
                    'count': len(range_results),
                    'mean_abs_error': np.mean(errors),
                    'std_error': np.std(errors),
                    'max_error': max(errors),
                    'median_error': np.median(errors)
                }
        
        return range_analysis
    
    def analyze_advantage_accuracy(self) -> Dict:
        """Analyze accuracy of advantage detection (white/black/even)"""
        correct_advantage = 0
        correct_even = 0
        total_even = 0
        white_advantage_correct = 0
        black_advantage_correct = 0
        white_advantage_total = 0
        black_advantage_total = 0
        
        for result in self.results:
            expected = result['expected_cp']
            predicted = result['predicted_cp']
            
            # Check if position is even
            if expected == 0:
                total_even += 1
                if abs(predicted) < 10:  # Allow small margin for "even"
                    correct_even += 1
            # Check white advantage
            elif expected > 0:
                white_advantage_total += 1
                if predicted > 0:
                    white_advantage_correct += 1
                    correct_advantage += 1
            # Check black advantage
            else:  # expected < 0
                black_advantage_total += 1
                if predicted < 0:
                    black_advantage_correct += 1
                    correct_advantage += 1
        
        total = len(self.results)
        non_even_total = white_advantage_total + black_advantage_total
        
        return {
            'overall_accuracy': (correct_advantage + correct_even) / total if total > 0 else 0,
            'advantage_detection_accuracy': correct_advantage / non_even_total if non_even_total > 0 else 0,
            'white_advantage_accuracy': white_advantage_correct / white_advantage_total if white_advantage_total > 0 else 0,
            'black_advantage_accuracy': black_advantage_correct / black_advantage_total if black_advantage_total > 0 else 0,
            'even_position_accuracy': correct_even / total_even if total_even > 0 else 0,
            'white_advantage_count': white_advantage_total,
            'black_advantage_count': black_advantage_total,
            'even_position_count': total_even
        }
    
    def analyze_performance(self) -> Dict:
        """Analyze evaluation speed performance"""
        eval_times = [r['eval_time'] for r in self.results]
        
        return {
            'total_positions': len(eval_times),
            'total_time': sum(eval_times),
            'mean_eval_time': np.mean(eval_times),
            'median_eval_time': np.median(eval_times),
            'min_eval_time': min(eval_times),
            'max_eval_time': max(eval_times),
            'evaluations_per_second': 1 / np.mean(eval_times) if eval_times else 0
        }
    
    def print_report(self):
        """Print comprehensive test report"""
        print("\n" + "=" * 60)
        print("TEST RESULTS SUMMARY")
        print("=" * 60)
        
        # Overall statistics
        print("\n📊 OVERALL STATISTICS")
        print("-" * 30)
        errors = [r['abs_error'] for r in self.results]
        print(f"Total positions tested: {len(self.results)}")
        print(f"Mean absolute error: {np.mean(errors):.2f} cp")
        print(f"Standard deviation: {np.std(errors):.2f} cp")
        print(f"Median absolute error: {np.median(errors):.2f} cp")
        print(f"Maximum error: {max(errors):.2f} cp")
        
        # Advantage detection accuracy
        print("\n🎯 ADVANTAGE DETECTION ACCURACY")
        print("-" * 30)
        adv_accuracy = self.analyze_advantage_accuracy()
        print(f"Overall accuracy: {adv_accuracy['overall_accuracy']*100:.1f}%")
        print(f"White advantage: {adv_accuracy['white_advantage_accuracy']*100:.1f}% ({adv_accuracy['white_advantage_count']} positions)")
        print(f"Black advantage: {adv_accuracy['black_advantage_accuracy']*100:.1f}% ({adv_accuracy['black_advantage_count']} positions)")
        if adv_accuracy['even_position_count'] > 0:
            print(f"Even positions: {adv_accuracy['even_position_accuracy']*100:.1f}% ({adv_accuracy['even_position_count']} positions)")
        
        # Performance metrics
        print("\n⚡ PERFORMANCE METRICS")
        print("-" * 30)
        perf = self.analyze_performance()
        print(f"Evaluations per second: {perf['evaluations_per_second']:.1f}")
        print(f"Average evaluation time: {perf['mean_eval_time']*1000:.3f} ms")
        print(f"Median evaluation time: {perf['median_eval_time']*1000:.3f} ms")
        
        # Summary of worst predictions
        print("\n❌ WORST PREDICTIONS (Top 3)")
        print("-" * 30)
        sorted_results = sorted(self.results, key=lambda x: x['abs_error'], reverse=True)[:3]
        for i, result in enumerate(sorted_results, 1):
            print(f"{i}. Error: {result['abs_error']:.0f} cp (expected: {result['expected_cp']:.0f}, got: {result['predicted_cp']:.0f})")
        
        print("\n" + "=" * 60)
    
    def generate_detailed_report(self) -> str:
        """Generate detailed report for file output"""
        report = []
        report.append("=" * 80)
        report.append("CHESS EVALUATOR DETAILED TEST REPORT")
        report.append("=" * 80)
        
        # Overall statistics
        report.append("\n1. OVERALL STATISTICS")
        report.append("-" * 40)
        errors = [r['abs_error'] for r in self.results]
        report.append(f"Total positions tested: {len(self.results)}")
        report.append(f"Mean absolute error: {np.mean(errors):.2f} cp")
        report.append(f"Standard deviation: {np.std(errors):.2f} cp")
        report.append(f"Median absolute error: {np.median(errors):.2f} cp")
        report.append(f"Maximum error: {max(errors):.2f} cp")
        
        # Accuracy by CP range
        report.append("\n2. ACCURACY BY CENTIPAWN RANGE")
        report.append("-" * 40)
        range_analysis = self.analyze_accuracy_by_range()
        for category, stats in range_analysis.items():
            report.append(f"\n{category}:")
            report.append(f"  Positions: {stats['count']}")
            report.append(f"  Mean error: {stats['mean_abs_error']:.2f} cp")
            report.append(f"  Std deviation: {stats['std_error']:.2f} cp")
            report.append(f"  Max error: {stats['max_error']:.2f} cp")
        
        # Advantage detection accuracy
        report.append("\n3. ADVANTAGE DETECTION ACCURACY")
        report.append("-" * 40)
        adv_accuracy = self.analyze_advantage_accuracy()
        report.append(f"Overall accuracy: {adv_accuracy['overall_accuracy']*100:.1f}%")
        report.append(f"Advantage detection accuracy: {adv_accuracy['advantage_detection_accuracy']*100:.1f}%")
        report.append(f"  White advantage accuracy: {adv_accuracy['white_advantage_accuracy']*100:.1f}% ({adv_accuracy['white_advantage_count']} positions)")
        report.append(f"  Black advantage accuracy: {adv_accuracy['black_advantage_accuracy']*100:.1f}% ({adv_accuracy['black_advantage_count']} positions)")
        report.append(f"  Even position accuracy: {adv_accuracy['even_position_accuracy']*100:.1f}% ({adv_accuracy['even_position_count']} positions)")
        
        # Performance metrics
        report.append("\n4. PERFORMANCE METRICS")
        report.append("-" * 40)
        perf = self.analyze_performance()
        report.append(f"Evaluations per second: {perf['evaluations_per_second']:.1f}")
        report.append(f"Mean evaluation time: {perf['mean_eval_time']*1000:.3f} ms")
        report.append(f"Median evaluation time: {perf['median_eval_time']*1000:.3f} ms")
        report.append(f"Min/Max evaluation time: {perf['min_eval_time']*1000:.3f} / {perf['max_eval_time']*1000:.3f} ms")
        
        # Individual results
        report.append("\n5. INDIVIDUAL POSITION RESULTS")
        report.append("-" * 40)
        report.append(f"{'Expected':>10} {'Predicted':>10} {'Error':>10} {'Time (ms)':>10}  FEN")
        report.append("-" * 80)
        for result in self.results:
            report.append(f"{result['expected_cp']:>10.0f} {result['predicted_cp']:>10.0f} "
                         f"{result['error']:>10.0f} {result['eval_time']*1000:>10.3f}  {result['fen']}")
        
        return "\n".join(report)


def main():
    """Main test runner"""
    # Configure paths
    model_path = "models/chess_model.bin"  # Update this path
    test_data_path = "tests/test_data.csv"
    results_dir = "tests/results"
    
    # Check if files exist
    if not os.path.exists(test_data_path):
        print(f"Error: Test data file not found at {test_data_path}")
        return
    
    # Create results directory if it doesn't exist
    os.makedirs(results_dir, exist_ok=True)
    
    # Create and run tester
    try:
        print("=" * 60)
        print("CHESS EVALUATOR PERFORMANCE TEST")
        print("=" * 60)
        
        tester = ChessEvaluatorTester(model_path, test_data_path)
        print(f"\n✓ Model loaded from: {model_path}")
        print(f"✓ Test data loaded from: {test_data_path}")
        
        print(f"\nEvaluating {len(tester.test_data)} positions...")
        start_time = time.time()
        tester.run_evaluations()
        total_time = time.time() - start_time
        
        print(f"✓ Completed in {total_time:.2f} seconds")
        
        # Print comprehensive report
        tester.print_report()
        
        # Save detailed results to CSV
        results_df = pd.DataFrame(tester.results)
        results_path = os.path.join(results_dir, "test_results.csv")
        results_df.to_csv(results_path, index=False)
        print(f"\n✓ Detailed results saved to: {results_path}")
        
        # Save summary report
        summary_path = os.path.join(results_dir, "test_summary.txt")
        with open(summary_path, 'w') as f:
            f.write(tester.generate_detailed_report())
        print(f"✓ Summary report saved to: {summary_path}")
        
    except FileNotFoundError as e:
        print(f"\n✗ Error: Model file not found at {model_path}")
        print("  Please ensure the model file exists or update the path.")
    except Exception as e:
        print(f"\n✗ Error during testing: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()