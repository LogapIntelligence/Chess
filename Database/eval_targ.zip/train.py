import numpy as np
import struct
import json
from typing import List, Tuple, Generator
import tensorflow as tf
from tensorflow import keras
import os
import csv
import pandas as pd
import glob
import re

class ChessPositionEncoder:
    """Efficient FEN position encoder"""
    
    PIECES = {
        'P': 1, 'N': 2, 'B': 3, 'R': 4, 'Q': 5, 'K': 6,
        'p': -1, 'n': -2, 'b': -3, 'r': -4, 'q': -5, 'k': -6
    }
    
    @staticmethod
    def encode_fen(fen: str) -> np.ndarray:
        """Convert FEN string to neural network input"""
        parts = fen.split()
        board_str = parts[0]
        
        # Board representation (8x8 = 64 values)
        board = np.zeros(64, dtype=np.float32)
        row, col = 0, 0
        
        for char in board_str:
            if char == '/':
                row += 1
                col = 0
            elif char.isdigit():
                col += int(char)
            else:
                idx = row * 8 + col
                board[idx] = ChessPositionEncoder.PIECES.get(char, 0) / 6.0  # Normalize
                col += 1
        
        # Additional features
        features = []
        
        # Active color (1 for white, -1 for black)
        if len(parts) > 1:
            features.append(1.0 if parts[1] == 'w' else -1.0)
        else:
            features.append(0.0)
        
        # Castling rights (4 values)
        if len(parts) > 2:
            castling = parts[2]
            features.extend([
                1.0 if 'K' in castling else 0.0,
                1.0 if 'Q' in castling else 0.0,
                1.0 if 'k' in castling else 0.0,
                1.0 if 'q' in castling else 0.0
            ])
        else:
            features.extend([0.0, 0.0, 0.0, 0.0])
        
        # En passant (1 value: normalized file position)
        if len(parts) > 3 and parts[3] != '-':
            file_idx = ord(parts[3][0]) - ord('a')
            features.append(file_idx / 7.0)
        else:
            features.append(-1.0)
        
        # Combine all features
        return np.concatenate([board, features])

class LightweightChessModel:
    """Efficient neural network for chess position evaluation"""
    
    def __init__(self, hidden_sizes: List[int] = [128, 64, 32]):
        self.input_size = 70  # 64 board + 6 additional features
        self.hidden_sizes = hidden_sizes
        self.model = self._build_model()
        
    def _build_model(self):
        """Build a small, efficient neural network"""
        inputs = keras.Input(shape=(self.input_size,))
        x = inputs
        
        # Hidden layers with decreasing size
        for i, size in enumerate(self.hidden_sizes):
            x = keras.layers.Dense(
                size, 
                activation='relu',
                kernel_regularizer=keras.regularizers.l2(0.001),
                name=f'hidden_{i}'
            )(x)
            x = keras.layers.Dropout(0.2)(x)
        
        # Output layer (single evaluation score)
        outputs = keras.layers.Dense(1, activation='tanh', name='output')(x)
        
        model = keras.Model(inputs=inputs, outputs=outputs)
        return model
    
    def compile(self, learning_rate: float = 0.001):
        """Compile the model"""
        self.model.compile(
            optimizer=keras.optimizers.Adam(learning_rate),
            loss='mse',
            metrics=['mae']
        )
    
    def export_weights(self, filepath: str):
        """Export model weights in a compact binary format"""
        # Ensure directory exists
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        weights_data = {
            'architecture': {
                'input_size': self.input_size,
                'hidden_sizes': self.hidden_sizes
            },
            'weights': []
        }
        
        # Extract all weights and biases
        for layer in self.model.layers:
            if hasattr(layer, 'get_weights'):
                layer_weights = layer.get_weights()
                if layer_weights:
                    weights_data['weights'].append({
                        'name': layer.name,
                        'weights': [w.tolist() for w in layer_weights]
                    })
        
        # Save as binary file for compactness
        with open(filepath + '.json', 'w') as f:
            json.dump(weights_data, f)
        
        # Also save in ultra-compact binary format
        self._export_binary(filepath + '.bin')
    
    def _export_binary(self, filepath: str):
        """Export weights in ultra-compact binary format"""
        with open(filepath, 'wb') as f:
            # Write architecture info
            f.write(struct.pack('I', self.input_size))
            f.write(struct.pack('I', len(self.hidden_sizes)))
            for size in self.hidden_sizes:
                f.write(struct.pack('I', size))
            
            # Write weights
            for layer in self.model.layers:
                if hasattr(layer, 'get_weights'):
                    layer_weights = layer.get_weights()
                    for weight_matrix in layer_weights:
                        # Flatten and write as float32
                        flat_weights = weight_matrix.flatten()
                        f.write(struct.pack(f'{len(flat_weights)}f', *flat_weights))

def get_chunk_files(data_dir: str = 'data') -> List[Tuple[str, int, int]]:
    """Get all chunk files sorted by chunk number
    
    Returns:
        List of tuples (filepath, chunk_number, num_positions)
    """
    chunk_pattern = os.path.join(data_dir, 'chunk_*_*.csv')
    chunk_files = glob.glob(chunk_pattern)
    
    chunk_info = []
    for filepath in chunk_files:
        filename = os.path.basename(filepath)
        # Parse chunk_<num>_<positions>.csv
        match = re.match(r'chunk_(\d+)_(\d+)\.csv', filename)
        if match:
            chunk_num = int(match.group(1))
            num_positions = int(match.group(2))
            chunk_info.append((filepath, chunk_num, num_positions))
    
    # Sort by chunk number
    chunk_info.sort(key=lambda x: x[1])
    return chunk_info

def load_chunk_data(filepath: str) -> Tuple[np.ndarray, np.ndarray]:
    """Load all data from a single chunk file"""
    positions = []
    evaluations = []
    
    df = pd.read_csv(filepath)
    
    for _, row in df.iterrows():
        try:
            eval_score = float(row['cp'])
            fen_string = row['fen']
            
            # Normalize evaluation to [-1, 1] range
            eval_normalized = np.tanh(eval_score / 1000.0)
            
            # Encode FEN
            encoded = ChessPositionEncoder.encode_fen(fen_string)
            
            positions.append(encoded)
            evaluations.append(eval_normalized)
            
        except Exception as e:
            print(f"Error processing row: {row} - {e}")
            continue
    
    return np.array(positions), np.array(evaluations)

def load_chunk_batch(filepath: str, batch_size: int = 10000) -> Generator[Tuple[np.ndarray, np.ndarray], None, None]:
    """Load chunk file in batches"""
    chunks = pd.read_csv(filepath, chunksize=batch_size)
    
    for chunk in chunks:
        positions = []
        evaluations = []
        
        for _, row in chunk.iterrows():
            try:
                eval_score = float(row['cp'])
                fen_string = row['fen']
                
                # Normalize evaluation to [-1, 1] range
                eval_normalized = np.tanh(eval_score / 1000.0)
                
                # Encode FEN
                encoded = ChessPositionEncoder.encode_fen(fen_string)
                
                positions.append(encoded)
                evaluations.append(eval_normalized)
                
            except Exception as e:
                print(f"Error processing row: {row} - {e}")
                continue
        
        if positions:
            yield np.array(positions), np.array(evaluations)

def train_model_from_chunks(model: LightweightChessModel,
                          data_dir: str,
                          epochs: int,
                          batch_size: int,
                          output_name: str,
                          validation_split: float = 0.1):
    """Train model from chunk files"""
    
    # Get all chunk files
    chunk_files = get_chunk_files(data_dir)
    if not chunk_files:
        raise ValueError(f"No chunk files found in {data_dir}")
    
    print(f"Found {len(chunk_files)} chunk files")
    total_positions = sum(num_pos for _, _, num_pos in chunk_files)
    print(f"Total positions across all chunks: {total_positions:,}")
    
    # Determine validation chunks (last 10% of chunks)
    num_val_chunks = max(1, int(len(chunk_files) * validation_split))
    train_chunks = chunk_files[:-num_val_chunks]
    val_chunks = chunk_files[-num_val_chunks:]
    
    print(f"\nUsing {len(train_chunks)} chunks for training, {len(val_chunks)} for validation")
    
    # Load validation data
    print("\nLoading validation data...")
    X_val, y_val = [], []
    for chunk_file, chunk_num, num_pos in val_chunks:
        print(f"  Loading validation chunk {chunk_num} ({num_pos} positions)...")
        chunk_X, chunk_y = load_chunk_data(chunk_file)
        X_val.append(chunk_X)
        y_val.append(chunk_y)
    
    X_val = np.vstack(X_val) if X_val else None
    y_val = np.concatenate(y_val) if y_val else None
    print(f"Validation set size: {len(X_val):,}" if X_val is not None else "No validation data")
    
    # Training loop
    print("\nStarting training...")
    best_val_loss = float('inf')
    patience_counter = 0
    
    # Ensure models directory exists
    os.makedirs('models', exist_ok=True)
    
    for epoch in range(epochs):
        print(f"\nEpoch {epoch + 1}/{epochs}")
        
        # Train on each chunk
        epoch_losses = []
        
        for chunk_idx, (chunk_file, chunk_num, num_pos) in enumerate(train_chunks):
            print(f"\n  Processing chunk {chunk_num} ({chunk_idx + 1}/{len(train_chunks)}) - {num_pos} positions")
            
            # Process chunk in batches
            chunk_losses = []
            batch_count = 0
            
            for batch_X, batch_y in load_chunk_batch(chunk_file, batch_size=10000):
                # Train on this batch
                history = model.model.fit(
                    batch_X, batch_y,
                    batch_size=batch_size,
                    epochs=1,
                    verbose=0
                )
                
                chunk_losses.append(history.history['loss'][0])
                batch_count += 1
                
                if batch_count % 5 == 0:
                    avg_loss = np.mean(chunk_losses)
                    print(f"    Chunk {chunk_num}, Batch {batch_count}: loss = {avg_loss:.4f}")
            
            avg_chunk_loss = np.mean(chunk_losses)
            epoch_losses.append(avg_chunk_loss)
            print(f"    Chunk {chunk_num} average loss: {avg_chunk_loss:.4f}")
        
        # Print epoch statistics
        avg_epoch_loss = np.mean(epoch_losses)
        print(f"\n  Epoch {epoch + 1} average loss: {avg_epoch_loss:.4f}")
        
        # Evaluate on validation set
        if X_val is not None:
            val_loss, val_mae = model.model.evaluate(X_val, y_val, verbose=0)
            print(f"  Validation: loss = {val_loss:.4f}, mae = {val_mae:.4f}")
            
            # Early stopping check
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                patience_counter = 0
                # Save best weights
                model.model.save_weights(f"models/{output_name}_best.weights.h5")
                print(f"  Saved best model (val_loss: {val_loss:.4f})")
            else:
                patience_counter += 1
                
            if patience_counter >= 5:
                print("\nEarly stopping triggered")
                # Restore best weights
                model.model.load_weights(f"models/{output_name}_best.weights.h5")
                break
        
        # Reduce learning rate if needed
        if patience_counter >= 3:
            current_lr = model.model.optimizer.learning_rate.numpy()
            new_lr = current_lr * 0.5
            model.model.optimizer.learning_rate.assign(new_lr)
            print(f"  Reduced learning rate to {new_lr:.6f}")

def train_model(
    data_dir: str = 'data',
    output_name: str = 'chess_model',
    target_size_mb: float = 2.0,
    epochs: int = 50,
    batch_size: int = 16384
):
    """Train the lightweight chess evaluation model
    
    Args:
        data_dir: Directory containing chunk files
        output_name: Name for output model files (saved to models/ directory)
        target_size_mb: Target model size in MB
        epochs: Number of training epochs
        batch_size: Training batch size
    """
    
    # Calculate approximate layer sizes for target model size
    if target_size_mb <= 1:
        hidden_sizes = [64, 32]
    elif target_size_mb <= 2:
        hidden_sizes = [128, 64, 32]
    elif target_size_mb <= 4:
        hidden_sizes = [256, 128, 64]
    else:
        hidden_sizes = [512, 256, 128, 64]
    
    print(f"Building model with architecture: {hidden_sizes}")
    
    # Create and compile model
    model = LightweightChessModel(hidden_sizes)
    model.compile(learning_rate=0.001)
    
    # Print model summary
    model.model.summary()
    
    # Calculate actual model size
    total_params = model.model.count_params()
    model_size_mb = (total_params * 4) / (1024 * 1024)  # 4 bytes per float32
    print(f"\nModel size: {model_size_mb:.2f} MB ({total_params} parameters)")
    
    # Train from chunks
    print(f"\nLoading data from {data_dir}/...")
    train_model_from_chunks(model, data_dir, epochs, batch_size, output_name)
    
    # Save final model
    print(f"\nSaving model to models/{output_name}...")
    os.makedirs('models', exist_ok=True)
    
    model.export_weights(f"models/{output_name}")
    model.model.save(f"models/{output_name}.keras")
    
    print("\nTraining complete!")
    
    return model

# Example usage and testing
if __name__ == "__main__":
    # Create sample chunk files if they don't exist
    os.makedirs('data', exist_ok=True)
    
    sample_chunk_files = [
        ('data/chunk_0_100000.csv', 0, 100000),
        ('data/chunk_1_100000.csv', 1, 100000),
        ('data/chunk_2_100000.csv', 2, 100000),
    ]
    
    # Check if sample data exists
    if not any(os.path.exists(f[0]) for f in sample_chunk_files):
        print("Creating sample chunk files...")
        
        sample_positions = [
            (0, 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1'),
            (40, 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1'),
            (30, 'rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq e6 0 2'),
            (40, 'rnbqkbnr/pppp1ppp/8/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R b KQkq - 1 2'),
            (34, 'rnbqkb1r/pppp1ppp/5n2/4p3/4P3/5N2/PPPP1PPP/RNBQKB1R w KQkq - 2 3'),
        ]
        
        for chunk_file, chunk_num, num_positions in sample_chunk_files[:1]:  # Create only first chunk for demo
            print(f"  Creating {chunk_file}...")
            data = [['cp', 'fen']]
            
            # Generate positions for this chunk
            for i in range(min(num_positions, 1000)):  # Limit to 1000 for demo
                idx = i % len(sample_positions)
                eval_score, fen = sample_positions[idx]
                # Add some variation
                eval_score += np.random.randint(-50, 50)
                data.append([eval_score, fen])
            
            # Save chunk
            df = pd.DataFrame(data[1:], columns=data[0])
            df.to_csv(chunk_file, index=False)
            print(f"    Created {chunk_file} with {len(data)-1} positions")
    
    # Train model from chunks
    print("\n" + "="*60)
    print("Training from chunk files")
    print("="*60)
    
    model = train_model(
        data_dir='data',
        output_name='chess_model',
        target_size_mb=2.0,
        epochs=100,  # Reduced for demo
        batch_size=16384
    )
    
    # Test inference
    print("\nTesting inference...")
    test_positions = [
        "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
        "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1",
        "r1bqkb1r/pppp1ppp/2n2n2/1B2p3/4P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4"
    ]
    
    for fen in test_positions:
        encoded = ChessPositionEncoder.encode_fen(fen)
        prediction = model.model.predict(encoded.reshape(1, -1), verbose=0)[0][0]
        print(f"\nPosition: {fen}")
        print(f"Evaluation: {prediction:.4f} (normalized)")
        print(f"Evaluation: {prediction * 1000:.0f} centipawns")
    
    print("\n" + "="*60)
    print("Training complete!")
    print("="*60)
    print(f"""
Models saved to:
  - models/{model.model.name}.keras (Keras format)
  - models/{model.model.name}.json (weights in JSON)
  - models/{model.model.name}.bin (weights in binary)
  - models/{model.model.name}_best.weights.h5 (best validation weights)

To use with large datasets:
1. Place chunk files in data/ directory with naming: chunk_<num>_<positions>.csv
2. Run: model = train_model(data_dir='data', output_name='my_model', epochs=50)
3. The trainer will process chunks sequentially to handle datasets larger than RAM
""")